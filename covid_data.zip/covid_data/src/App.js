import './App.css';
import CovidIndiaData from './components/CovidIndiaData';

function App() {
  return (
    <div className="App">
      <covidIndiaData />
    </div>
  );
}

export default App;
