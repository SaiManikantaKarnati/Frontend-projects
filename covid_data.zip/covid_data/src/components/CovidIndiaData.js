import React, { useState, useEffect } from 'react';
import './CovidIndiaData.css';

const CovidIndiaData = () => {
    const [data, setData] = useState(null);
    const [search, setSearch] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            const response  = await fetch('https://api.rootnet.in/covid19-in/stats/latest');
            const responseData = await response.json();
            setData(responseData.data.regional); 
        };
        fetchData();
    }, []);

    const handleChange = (event) => {
        setSearch(event.target.value);
    };

    const filteredData = data ? data.filter((item) => item.loc.toLowerCase().includes(search.toLowerCase())) : [];

    return (
        <div className="container">
            <div className="heading">
                <h1>Covid-19 data India</h1>
            </div>
            <div className="search">
                <input type="text" placeholder="Search by state" value={search} onChange={handleChange} />
            </div>
            <div className="cards">
                {filteredData.map((item, index) => (
                    <div className='card-items' key={index}>
                        <h2>{item.loc}</h2>
                        <div className="card-body">
                            <div className="card-list">
                                <span className='list1'>Local cases : </span>
                                <span className='list2'>{item.confirmedCasesIndian}</span>
                            </div>
                            <div className="card-list">
                                <span className='list1'>Foreigner cases : </span>
                                <span className='list2'>{item.confirmedCasesForeign}</span>
                            </div>
                            <div className="card-list">
                                <span className='list1'>Recovered : </span>
                                <span className='list2'>{item.discharged}</span>
                            </div>
                            <div className="card-list">
                                <span className='list1'>Deaths : </span>
                                <span className='list2'>{item.deaths}</span>
                            </div>
                            <hr></hr>
                            <div className="card-list">
                                <span className='list1'>Total cases : </span>
                                <span className='list2'>{item.totalConfirmed}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CovidIndiaData;